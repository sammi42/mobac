This is the jni library required by Mobile Atlas Creator 
for creating BigPlanet SQLite atlases.

==== Installation ===

Place the library in the same directory where you installed 
Mobile Atlas Creator (where "Mobile_Atlas_Creator.jar" is located). 

==== Requirements ===
This library requires MSVCR90.DLL which is included in the 
Microsoft Visual C++ 2008 Redistributable Package (x64)