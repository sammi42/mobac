This is the jni library required by Mobile Atlas Creator 
for creating BigPlanet SQLite atlases.

==== Installation ===

Place the library in the same directory where the file "Mobile_Atlas_Creator.jar"
is located.